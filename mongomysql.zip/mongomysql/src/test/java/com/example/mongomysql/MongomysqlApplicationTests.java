package com.example.mongomysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongomysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
