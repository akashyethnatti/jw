package com.example.mongomysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongomysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongomysqlApplication.class, args);
	}

}
