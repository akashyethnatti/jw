package com.example.j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JApplication {

	public static void main(String[] args) {
		SpringApplication.run(JApplication.class, args);
	}

}
